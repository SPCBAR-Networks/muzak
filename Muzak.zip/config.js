exports.TOKEN = 'NjM1MDAyODAyNDgxMTM1NjI2.XarFVA.6oXgshVwjNXsNRGM1f-_4KwCylk';

exports.PREFIX = '-';

exports.GOOGLE_API_KEY = 'AIzaSyCDbVGTxgNjMAmbZiq8Nh0Au12mJZAzi7s';
